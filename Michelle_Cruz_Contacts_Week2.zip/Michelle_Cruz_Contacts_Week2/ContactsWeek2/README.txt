Michelle Cruz - Contacts Application - Week 2

Open this folder in VS Code with Java support and a JDK installed.
Run src/ContactApp.java using Run above main(), or use a terminal:
  javac -d out src/*.java
  java -cp out ContactApp

Enter 1 to display contacts, an unsupported choice to test validation,
and 2 to exit. Test 1 twice to verify that the menu repeats.

Week 2 adds Displayable.java. Contact implements this interface, and
ContactApp stores the three subclasses in a Displayable[] array.
Each display() call runs the override belonging to the actual object.
Address composition and the Week 1 contact data are retained.

Current demo: display three sample records, validate selections, repeat,
and exit. Adding, removing, updating, filtering, and SQLite storage are
planned for the final application and are not implemented in this demo.

Before submission: run the program locally and add actual screenshots
of the welcome/menu, all three contacts, invalid selection, and exit to
the Word document. Upload the source and document to the existing GitHub
repository, follow the course tagging instructions for Phase #2, and
paste the tag/release URL into the assignment Website URL field.
The assignment also requires adding the instructor as a collaborator.
